import { create } from 'zustand'
import { db } from '@/db'
import type { Session, MenuSnapshot } from '@/db/types'
import { generateId } from '@/lib/utils'
import { useMenuStore } from './menuStore'

interface SessionState {
  sessions: Session[]
  activeSession: Session | null
  loading: boolean
  
  // Actions
  loadSessions: () => Promise<void>
  startSession: () => Promise<Session>
  updateSession: (id: string, updates: Partial<Pick<Session, 'customerCount' | 'notes'>>) => Promise<void>
  updateSessionMenuSnapshot: (id: string) => Promise<void>
  endSession: (id: string) => Promise<void>
  getSession: (id: string) => Session | undefined
}

export const useSessionStore = create<SessionState>((set, get) => ({
  sessions: [],
  activeSession: null,
  loading: true,

  loadSessions: async () => {
    set({ loading: true })
    const sessions = await db.sessions.orderBy('startedAt').reverse().toArray()
    const activeSession = sessions.find((s) => s.status === 'active') || null
    set({ sessions, activeSession, loading: false })
  },

  startSession: async () => {
    // Check for existing active session
    const existing = get().activeSession
    if (existing) {
      throw new Error('A session is already active')
    }

    const menuSnapshot = useMenuStore.getState().getSnapshot()
    const newSession: Session = {
      id: generateId(),
      status: 'active',
      startedAt: Date.now(),
      notes: '',
      menuSnapshot,
    }

    await db.sessions.add(newSession)
    set((state) => ({
      sessions: [newSession, ...state.sessions],
      activeSession: newSession,
    }))
    return newSession
  },

  updateSession: async (id, updates) => {
    await db.sessions.update(id, updates)
    set((state) => ({
      sessions: state.sessions.map((s) =>
        s.id === id ? { ...s, ...updates } : s
      ),
      activeSession:
        state.activeSession?.id === id
          ? { ...state.activeSession, ...updates }
          : state.activeSession,
    }))
  },

  updateSessionMenuSnapshot: async (id) => {
    const menuSnapshot = useMenuStore.getState().getSnapshot()
    await db.sessions.update(id, { menuSnapshot })
    set((state) => ({
      sessions: state.sessions.map((s) =>
        s.id === id ? { ...s, menuSnapshot } : s
      ),
      activeSession:
        state.activeSession?.id === id
          ? { ...state.activeSession, menuSnapshot }
          : state.activeSession,
    }))
  },

  endSession: async (id) => {
    const endedAt = Date.now()
    await db.sessions.update(id, { status: 'closed', endedAt })
    set((state) => ({
      sessions: state.sessions.map((s) =>
        s.id === id ? { ...s, status: 'closed', endedAt } : s
      ),
      activeSession: null,
    }))
  },

  getSession: (id) => {
    return get().sessions.find((s) => s.id === id)
  },
}))
