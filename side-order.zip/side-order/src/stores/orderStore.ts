import { create } from 'zustand'
import { db } from '@/db'
import type { Order, NewOrder } from '@/db/types'
import { generateId } from '@/lib/utils'

interface OrderState {
  orders: Order[]
  loading: boolean
  
  // Actions
  loadOrders: (sessionId: string) => Promise<void>
  addOrder: (order: NewOrder) => Promise<Order>
  updateOrder: (id: string, updates: Partial<Order>) => Promise<void>
  deleteOrder: (id: string) => Promise<void>
  getSessionOrders: (sessionId: string) => Order[]
  clearOrders: () => void
}

export const useOrderStore = create<OrderState>((set, get) => ({
  orders: [],
  loading: false,

  loadOrders: async (sessionId) => {
    set({ loading: true })
    const orders = await db.orders
      .where('sessionId')
      .equals(sessionId)
      .sortBy('timestamp')
    set({ orders, loading: false })
  },

  addOrder: async (order) => {
    const newOrder: Order = {
      ...order,
      id: generateId(),
      timestamp: Date.now(),
    }
    await db.orders.add(newOrder)
    set((state) => ({ orders: [...state.orders, newOrder] }))
    return newOrder
  },

  updateOrder: async (id, updates) => {
    await db.orders.update(id, updates)
    set((state) => ({
      orders: state.orders.map((o) =>
        o.id === id ? { ...o, ...updates } : o
      ),
    }))
  },

  deleteOrder: async (id) => {
    await db.orders.delete(id)
    set((state) => ({
      orders: state.orders.filter((o) => o.id !== id),
    }))
  },

  getSessionOrders: (sessionId) => {
    return get().orders.filter((o) => o.sessionId === sessionId)
  },

  clearOrders: () => {
    set({ orders: [] })
  },
}))
