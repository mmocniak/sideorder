import Dexie, { type EntityTable } from 'dexie'
import type { MenuItem, CustomizationOption, Session, Order } from './types'

const db = new Dexie('SideOrderDB') as Dexie & {
  menuItems: EntityTable<MenuItem, 'id'>
  customizations: EntityTable<CustomizationOption, 'id'>
  sessions: EntityTable<Session, 'id'>
  orders: EntityTable<Order, 'id'>
}

db.version(1).stores({
  menuItems: 'id, category, available, createdAt',
  customizations: 'id, category, available',
  sessions: 'id, status, startedAt',
  orders: 'id, sessionId, timestamp',
})

export { db }

// Seed default customizations if empty
export async function seedDefaults() {
  const customizationCount = await db.customizations.count()
  
  if (customizationCount === 0) {
    await db.customizations.bulkAdd([
      // Temperatures
      { id: crypto.randomUUID(), category: 'temperature', name: 'Hot', available: true },
      { id: crypto.randomUUID(), category: 'temperature', name: 'Iced', available: true },
      
      // Milks
      { id: crypto.randomUUID(), category: 'milk', name: 'Whole', available: true },
      { id: crypto.randomUUID(), category: 'milk', name: 'Oat', available: true },
      { id: crypto.randomUUID(), category: 'milk', name: 'Almond', available: true },
      { id: crypto.randomUUID(), category: 'milk', name: '2%', available: true },
      { id: crypto.randomUUID(), category: 'milk', name: 'None', available: true },
      
      // Syrups
      { id: crypto.randomUUID(), category: 'syrup', name: 'Vanilla', available: true },
      { id: crypto.randomUUID(), category: 'syrup', name: 'Caramel', available: true },
      { id: crypto.randomUUID(), category: 'syrup', name: 'Hazelnut', available: true },
      { id: crypto.randomUUID(), category: 'syrup', name: 'Mocha', available: true },
      { id: crypto.randomUUID(), category: 'syrup', name: 'None', available: true },
      
      // Sizes
      { id: crypto.randomUUID(), category: 'size', name: 'Small', available: true },
      { id: crypto.randomUUID(), category: 'size', name: 'Medium', available: true },
      { id: crypto.randomUUID(), category: 'size', name: 'Large', available: true },
    ])
  }

  const menuCount = await db.menuItems.count()
  
  if (menuCount === 0) {
    const now = Date.now()
    await db.menuItems.bulkAdd([
      { id: crypto.randomUUID(), name: 'Espresso', category: 'espresso', available: true, createdAt: now, updatedAt: now },
      { id: crypto.randomUUID(), name: 'Americano', category: 'espresso', available: true, createdAt: now, updatedAt: now },
      { id: crypto.randomUUID(), name: 'Latte', category: 'espresso', available: true, createdAt: now, updatedAt: now },
      { id: crypto.randomUUID(), name: 'Cappuccino', category: 'espresso', available: true, createdAt: now, updatedAt: now },
      { id: crypto.randomUUID(), name: 'Mocha', category: 'espresso', available: true, createdAt: now, updatedAt: now },
      { id: crypto.randomUUID(), name: 'Drip Coffee', category: 'drip', available: true, createdAt: now, updatedAt: now },
      { id: crypto.randomUUID(), name: 'Pour Over', category: 'drip', available: true, createdAt: now, updatedAt: now },
      { id: crypto.randomUUID(), name: 'Cold Brew', category: 'drip', available: true, createdAt: now, updatedAt: now },
    ])
  }
}
