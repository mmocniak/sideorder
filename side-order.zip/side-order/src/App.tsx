import { useEffect } from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { AppShell } from '@/components/layout/AppShell'
import { Home } from '@/pages/Home'
import { ActiveSession } from '@/pages/ActiveSession'
import { SessionHistory } from '@/pages/SessionHistory'
import { SessionDetail } from '@/pages/SessionDetail'
import { Menu } from '@/pages/Menu'
import { seedDefaults } from '@/db'

export default function App() {
  useEffect(() => {
    seedDefaults()
  }, [])

  return (
    <BrowserRouter>
      <Routes>
        <Route element={<AppShell />}>
          <Route path="/" element={<Home />} />
          <Route path="/session" element={<ActiveSession />} />
          <Route path="/history" element={<SessionHistory />} />
          <Route path="/history/:id" element={<SessionDetail />} />
          <Route path="/menu" element={<Menu />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}
