import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Play, Coffee } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { SessionCard } from '@/components/session/SessionCard'
import { useSessionStore } from '@/stores/sessionStore'
import { useMenuStore } from '@/stores/menuStore'
import { db } from '@/db'
import type { Session } from '@/db/types'

export function Home() {
  const navigate = useNavigate()
  const { sessions, activeSession, loading, loadSessions, startSession } =
    useSessionStore()
  const { loadMenu } = useMenuStore()
  const [orderCounts, setOrderCounts] = useState<Record<string, number>>({})

  useEffect(() => {
    loadSessions()
    loadMenu()
  }, [loadSessions, loadMenu])

  useEffect(() => {
    // Load order counts for recent sessions
    async function loadOrderCounts() {
      const counts: Record<string, number> = {}
      for (const session of sessions.slice(0, 5)) {
        counts[session.id] = await db.orders
          .where('sessionId')
          .equals(session.id)
          .count()
      }
      setOrderCounts(counts)
    }
    if (sessions.length > 0) {
      loadOrderCounts()
    }
  }, [sessions])

  const handleStartSession = async () => {
    const session = await startSession()
    navigate('/session')
  }

  const recentSessions = sessions.filter((s) => s.status === 'closed').slice(0, 3)

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Coffee className="h-8 w-8 animate-pulse text-espresso" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="font-display text-2xl font-bold text-roast">
          Welcome back
        </h1>
        <p className="text-muted-foreground mt-1">
          {activeSession
            ? 'You have an active session running.'
            : 'Ready to start a new session?'}
        </p>
      </div>

      {/* Active Session or Start New */}
      {activeSession ? (
        <SessionCard
          session={activeSession}
          orderCount={orderCounts[activeSession.id] ?? 0}
        />
      ) : (
        <Card className="border-dashed border-2 border-oat-300 bg-transparent">
          <CardContent className="flex flex-col items-center py-8">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-terracotta/10 mb-4">
              <Coffee className="h-7 w-7 text-terracotta" />
            </div>
            <h2 className="font-display text-lg font-semibold text-roast mb-2">
              No Active Session
            </h2>
            <p className="text-sm text-muted-foreground text-center mb-4">
              Start a session to begin tracking orders for today.
            </p>
            <Button variant="accent" size="lg" onClick={handleStartSession}>
              <Play className="h-5 w-5 mr-2" />
              Start Session
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Recent Sessions */}
      {recentSessions.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-semibold text-roast">
              Recent Sessions
            </h2>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/history')}
            >
              View all
            </Button>
          </div>
          <div className="space-y-3">
            {recentSessions.map((session) => (
              <SessionCard
                key={session.id}
                session={session}
                orderCount={orderCounts[session.id] ?? 0}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
