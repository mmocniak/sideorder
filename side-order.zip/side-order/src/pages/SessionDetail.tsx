import { useEffect } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { ArrowLeft, Coffee } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { SessionStats } from '@/components/session/SessionStats'
import { OrderList } from '@/components/session/OrderList'
import { useSessionStore } from '@/stores/sessionStore'
import { useOrderStore } from '@/stores/orderStore'
import { formatDate, formatTime } from '@/lib/utils'

export function SessionDetail() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const { sessions, loading: sessionsLoading, loadSessions, getSession } = useSessionStore()
  const { orders, loading: ordersLoading, loadOrders } = useOrderStore()

  useEffect(() => {
    loadSessions()
  }, [loadSessions])

  useEffect(() => {
    if (id) {
      loadOrders(id)
    }
  }, [id, loadOrders])

  const session = id ? getSession(id) : undefined

  if (sessionsLoading || ordersLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Coffee className="h-8 w-8 animate-pulse text-espresso" />
      </div>
    )
  }

  if (!session) {
    return (
      <div className="space-y-6">
        <Button variant="ghost" onClick={() => navigate('/history')}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to History
        </Button>
        <Card>
          <CardContent className="py-12 text-center">
            <h2 className="font-display text-lg font-semibold text-roast">
              Session Not Found
            </h2>
            <p className="text-muted-foreground mt-2">
              This session may have been deleted.
            </p>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Group orders by item for summary
  const orderSummary = orders.reduce(
    (acc, order) => {
      const key = order.itemName
      if (!acc[key]) acc[key] = 0
      acc[key]++
      return acc
    },
    {} as Record<string, number>
  )

  const sortedSummary = Object.entries(orderSummary).sort((a, b) => b[1] - a[1])

  return (
    <div className="space-y-6">
      {/* Back link */}
      <Button variant="ghost" onClick={() => navigate('/history')}>
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to History
      </Button>

      {/* Header */}
      <div>
        <h1 className="font-display text-2xl font-bold text-roast">
          {formatDate(session.startedAt)}
        </h1>
        <p className="text-muted-foreground mt-1">
          {formatTime(session.startedAt)}
          {session.endedAt && ` — ${formatTime(session.endedAt)}`}
        </p>
        {session.notes && (
          <p className="text-sm text-muted-foreground mt-2 italic">
            "{session.notes}"
          </p>
        )}
      </div>

      {/* Stats */}
      <SessionStats session={session} orderCount={orders.length} />

      {/* Order Summary */}
      {sortedSummary.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Order Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {sortedSummary.map(([item, count]) => (
                <div
                  key={item}
                  className="flex items-center justify-between text-sm"
                >
                  <span className="text-roast">{item}</span>
                  <span className="text-muted-foreground">×{count}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Full Order List */}
      <OrderList orders={orders} />

      {/* Menu Snapshot Info */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Menu at Time of Session</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-3">
            {session.menuSnapshot.items.length} items available
          </p>
          <div className="flex flex-wrap gap-2">
            {session.menuSnapshot.items.map((item) => (
              <span
                key={item.id}
                className="inline-flex items-center rounded-full bg-oat-100 px-2.5 py-0.5 text-xs text-roast"
              >
                {item.name}
              </span>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
