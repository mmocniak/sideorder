import { useEffect, useState } from 'react'
import { Coffee } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { SessionCard } from '@/components/session/SessionCard'
import { useSessionStore } from '@/stores/sessionStore'
import { db } from '@/db'

export function SessionHistory() {
  const { sessions, loading, loadSessions } = useSessionStore()
  const [orderCounts, setOrderCounts] = useState<Record<string, number>>({})

  useEffect(() => {
    loadSessions()
  }, [loadSessions])

  useEffect(() => {
    async function loadOrderCounts() {
      const counts: Record<string, number> = {}
      for (const session of sessions) {
        counts[session.id] = await db.orders
          .where('sessionId')
          .equals(session.id)
          .count()
      }
      setOrderCounts(counts)
    }
    if (sessions.length > 0) {
      loadOrderCounts()
    }
  }, [sessions])

  const closedSessions = sessions.filter((s) => s.status === 'closed')

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Coffee className="h-8 w-8 animate-pulse text-espresso" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-roast">
          Session History
        </h1>
        <p className="text-muted-foreground mt-1">
          {closedSessions.length} past session
          {closedSessions.length !== 1 ? 's' : ''}
        </p>
      </div>

      {closedSessions.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Coffee className="h-12 w-12 mx-auto mb-4 text-oat-400" />
            <h2 className="font-display text-lg font-semibold text-roast mb-2">
              No Past Sessions
            </h2>
            <p className="text-sm text-muted-foreground">
              Completed sessions will appear here so you can review orders and
              track usage over time.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {closedSessions.map((session) => (
            <SessionCard
              key={session.id}
              session={session}
              orderCount={orderCounts[session.id] ?? 0}
            />
          ))}
        </div>
      )}
    </div>
  )
}
