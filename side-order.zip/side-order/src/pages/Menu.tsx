import { useEffect, useState } from 'react'
import { Plus, Coffee } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { MenuItemCard } from '@/components/menu/MenuItemCard'
import { MenuItemForm } from '@/components/menu/MenuItemForm'
import { CustomizationManager } from '@/components/menu/CustomizationManager'
import { useMenuStore } from '@/stores/menuStore'
import { useSessionStore } from '@/stores/sessionStore'
import type { MenuItem } from '@/db/types'

export function Menu() {
  const {
    items,
    customizations,
    loading,
    loadMenu,
    addItem,
    updateItem,
    deleteItem,
    addCustomization,
    updateCustomization,
    deleteCustomization,
  } = useMenuStore()

  const { activeSession, updateSessionMenuSnapshot } = useSessionStore()

  const [showItemForm, setShowItemForm] = useState(false)
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null)

  useEffect(() => {
    loadMenu()
  }, [loadMenu])

  const handleSaveItem = async (data: Partial<MenuItem>) => {
    if (editingItem) {
      await updateItem(editingItem.id, data)
    } else {
      await addItem(data as Parameters<typeof addItem>[0])
    }
    // Update active session snapshot if one exists
    if (activeSession) {
      await updateSessionMenuSnapshot(activeSession.id)
    }
    setEditingItem(null)
  }

  const handleDeleteItem = async (id: string) => {
    await deleteItem(id)
    if (activeSession) {
      await updateSessionMenuSnapshot(activeSession.id)
    }
  }

  const handleToggleItem = async (id: string, available: boolean) => {
    await updateItem(id, { available })
    if (activeSession) {
      await updateSessionMenuSnapshot(activeSession.id)
    }
  }

  const handleAddCustomization = async (
    category: Parameters<typeof addCustomization>[0]['category'],
    name: string
  ) => {
    await addCustomization({ category, name, available: true })
    if (activeSession) {
      await updateSessionMenuSnapshot(activeSession.id)
    }
  }

  const handleToggleCustomization = async (id: string, available: boolean) => {
    await updateCustomization(id, { available })
    if (activeSession) {
      await updateSessionMenuSnapshot(activeSession.id)
    }
  }

  const handleDeleteCustomization = async (id: string) => {
    await deleteCustomization(id)
    if (activeSession) {
      await updateSessionMenuSnapshot(activeSession.id)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Coffee className="h-8 w-8 animate-pulse text-espresso" />
      </div>
    )
  }

  // Group items by category
  const itemsByCategory = items.reduce(
    (acc, item) => {
      if (!acc[item.category]) acc[item.category] = []
      acc[item.category].push(item)
      return acc
    },
    {} as Record<string, MenuItem[]>
  )

  const categoryOrder = ['espresso', 'drip', 'tea', 'other']

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-roast">Menu</h1>
        <p className="text-muted-foreground mt-1">
          Manage your drink menu and customization options
        </p>
      </div>

      <Tabs defaultValue="items">
        <TabsList className="w-full">
          <TabsTrigger value="items" className="flex-1">
            Items
          </TabsTrigger>
          <TabsTrigger value="customizations" className="flex-1">
            Customizations
          </TabsTrigger>
        </TabsList>

        <TabsContent value="items">
          <div className="space-y-6">
            <Button
              variant="accent"
              className="w-full"
              onClick={() => {
                setEditingItem(null)
                setShowItemForm(true)
              }}
            >
              <Plus className="h-5 w-5 mr-2" />
              Add Menu Item
            </Button>

            {categoryOrder.map(
              (category) =>
                itemsByCategory[category]?.length > 0 && (
                  <div key={category} className="space-y-2">
                    <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                      {category}
                    </h2>
                    <div className="space-y-2">
                      {itemsByCategory[category].map((item) => (
                        <MenuItemCard
                          key={item.id}
                          item={item}
                          onEdit={(item) => {
                            setEditingItem(item)
                            setShowItemForm(true)
                          }}
                          onDelete={handleDeleteItem}
                          onToggleAvailable={handleToggleItem}
                        />
                      ))}
                    </div>
                  </div>
                )
            )}

            {items.length === 0 && (
              <div className="py-8 text-center text-muted-foreground">
                No menu items yet. Add your first drink!
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="customizations">
          <CustomizationManager
            customizations={customizations}
            onAdd={handleAddCustomization}
            onToggle={handleToggleCustomization}
            onDelete={handleDeleteCustomization}
          />
        </TabsContent>
      </Tabs>

      <MenuItemForm
        open={showItemForm}
        onOpenChange={setShowItemForm}
        item={editingItem}
        onSave={handleSaveItem}
      />
    </div>
  )
}
