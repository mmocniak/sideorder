import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Square, Settings, Coffee } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { SessionStats } from '@/components/session/SessionStats'
import { OrderEntry } from '@/components/session/OrderEntry'
import { OrderList } from '@/components/session/OrderList'
import { useSessionStore } from '@/stores/sessionStore'
import { useMenuStore } from '@/stores/menuStore'
import { useOrderStore } from '@/stores/orderStore'
import type { MenuItem, OrderCustomizations } from '@/db/types'

export function ActiveSession() {
  const navigate = useNavigate()
  const { activeSession, loadSessions, updateSession, endSession } =
    useSessionStore()
  const { items, customizations, loadMenu } = useMenuStore()
  const { orders, loadOrders, addOrder, deleteOrder } = useOrderStore()

  const [showSettings, setShowSettings] = useState(false)
  const [showEndConfirm, setShowEndConfirm] = useState(false)
  const [customerCount, setCustomerCount] = useState('')
  const [notes, setNotes] = useState('')

  // Refresh time display
  const [, setTick] = useState(0)
  useEffect(() => {
    const interval = setInterval(() => setTick((t) => t + 1), 60000)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    loadSessions()
    loadMenu()
  }, [loadSessions, loadMenu])

  useEffect(() => {
    if (activeSession) {
      loadOrders(activeSession.id)
      setCustomerCount(activeSession.customerCount?.toString() ?? '')
      setNotes(activeSession.notes)
    }
  }, [activeSession, loadOrders])

  useEffect(() => {
    if (!activeSession && !useSessionStore.getState().loading) {
      navigate('/')
    }
  }, [activeSession, navigate])

  if (!activeSession) {
    return (
      <div className="flex items-center justify-center py-12">
        <Coffee className="h-8 w-8 animate-pulse text-espresso" />
      </div>
    )
  }

  // Use session's menu snapshot for available items
  const availableItems = activeSession.menuSnapshot.items
  const availableCustomizations = activeSession.menuSnapshot.customizations

  const handleAddOrder = async (
    item: MenuItem,
    customizations: OrderCustomizations,
    orderNotes: string
  ) => {
    await addOrder({
      sessionId: activeSession.id,
      itemName: item.name,
      itemCategory: item.category,
      customizations,
      notes: orderNotes,
    })
  }

  const handleSaveSettings = async () => {
    await updateSession(activeSession.id, {
      customerCount: customerCount ? parseInt(customerCount, 10) : undefined,
      notes,
    })
    setShowSettings(false)
  }

  const handleEndSession = async () => {
    await endSession(activeSession.id)
    navigate('/')
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-roast">
            Active Session
          </h1>
          <p className="text-muted-foreground mt-1">
            Tap an item to log an order
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" onClick={() => setShowSettings(true)}>
            <Settings className="h-4 w-4" />
          </Button>
          <Button
            variant="destructive"
            size="sm"
            onClick={() => setShowEndConfirm(true)}
          >
            <Square className="h-4 w-4 mr-2" />
            End
          </Button>
        </div>
      </div>

      {/* Stats */}
      <SessionStats session={activeSession} orderCount={orders.length} />

      {/* Order Entry */}
      <OrderEntry
        menuItems={availableItems}
        customizations={availableCustomizations}
        onAddOrder={handleAddOrder}
      />

      {/* Order List */}
      <OrderList orders={orders} onDeleteOrder={deleteOrder} showDelete />

      {/* Settings Dialog */}
      <Dialog open={showSettings} onOpenChange={setShowSettings}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Session Settings</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="customerCount">Customer Count</Label>
              <Input
                id="customerCount"
                type="number"
                placeholder="How many customers?"
                value={customerCount}
                onChange={(e) => setCustomerCount(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Input
                id="notes"
                placeholder="Any notes for this session..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSettings(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveSettings}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* End Session Confirmation */}
      <Dialog open={showEndConfirm} onOpenChange={setShowEndConfirm}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>End Session?</DialogTitle>
          </DialogHeader>
          <p className="text-muted-foreground py-4">
            Are you sure you want to end this session? You won't be able to add
            more orders, but you can still view the session history.
          </p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEndConfirm(false)}>
              Keep Going
            </Button>
            <Button variant="destructive" onClick={handleEndSession}>
              End Session
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
