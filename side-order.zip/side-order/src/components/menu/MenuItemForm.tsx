import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import type { MenuItem, NewMenuItem } from '@/db/types'

interface MenuItemFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  item?: MenuItem | null
  onSave: (item: NewMenuItem | Partial<MenuItem>) => void
}

const categories: MenuItem['category'][] = ['espresso', 'drip', 'tea', 'other']

export function MenuItemForm({
  open,
  onOpenChange,
  item,
  onSave,
}: MenuItemFormProps) {
  const [name, setName] = useState('')
  const [category, setCategory] = useState<MenuItem['category']>('espresso')

  useEffect(() => {
    if (item) {
      setName(item.name)
      setCategory(item.category)
    } else {
      setName('')
      setCategory('espresso')
    }
  }, [item, open])

  const handleSubmit = () => {
    if (!name.trim()) return

    if (item) {
      onSave({ name: name.trim(), category })
    } else {
      onSave({ name: name.trim(), category, available: true })
    }
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{item ? 'Edit Item' : 'Add Item'}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              placeholder="e.g. Flat White"
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoFocus
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">Category</Label>
            <Select value={category} onValueChange={(v) => setCategory(v as MenuItem['category'])}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat} value={cat} className="capitalize">
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={!name.trim()}>
            {item ? 'Save Changes' : 'Add Item'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
