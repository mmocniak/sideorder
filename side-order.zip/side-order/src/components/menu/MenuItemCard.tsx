import { Pencil, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Switch } from '@/components/ui/switch'
import type { MenuItem } from '@/db/types'

interface MenuItemCardProps {
  item: MenuItem
  onEdit: (item: MenuItem) => void
  onDelete: (id: string) => void
  onToggleAvailable: (id: string, available: boolean) => void
}

export function MenuItemCard({
  item,
  onEdit,
  onDelete,
  onToggleAvailable,
}: MenuItemCardProps) {
  return (
    <Card className={!item.available ? 'opacity-60' : ''}>
      <CardContent className="flex items-center justify-between p-4">
        <div className="flex items-center gap-3 flex-1 min-w-0">
          <Switch
            checked={item.available}
            onCheckedChange={(checked) => onToggleAvailable(item.id, checked)}
          />
          <div className="flex-1 min-w-0">
            <span className="font-medium text-roast block truncate">
              {item.name}
            </span>
            <span className="text-xs text-muted-foreground capitalize">
              {item.category}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" onClick={() => onEdit(item)}>
            <Pencil className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="text-muted-foreground hover:text-destructive"
            onClick={() => onDelete(item.id)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
