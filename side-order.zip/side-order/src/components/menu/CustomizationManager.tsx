import { useState } from 'react'
import { Plus, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import type { CustomizationOption } from '@/db/types'

interface CustomizationManagerProps {
  customizations: CustomizationOption[]
  onAdd: (category: CustomizationOption['category'], name: string) => void
  onToggle: (id: string, available: boolean) => void
  onDelete: (id: string) => void
}

const categoryLabels: Record<CustomizationOption['category'], string> = {
  temperature: 'Temperature',
  milk: 'Milk',
  syrup: 'Syrup',
  size: 'Size',
}

const categoryOrder: CustomizationOption['category'][] = [
  'size',
  'temperature',
  'milk',
  'syrup',
]

export function CustomizationManager({
  customizations,
  onAdd,
  onToggle,
  onDelete,
}: CustomizationManagerProps) {
  const [newOptions, setNewOptions] = useState<
    Record<CustomizationOption['category'], string>
  >({
    temperature: '',
    milk: '',
    syrup: '',
    size: '',
  })

  const byCategory = customizations.reduce(
    (acc, c) => {
      if (!acc[c.category]) acc[c.category] = []
      acc[c.category].push(c)
      return acc
    },
    {} as Record<string, CustomizationOption[]>
  )

  const handleAdd = (category: CustomizationOption['category']) => {
    const name = newOptions[category].trim()
    if (!name) return
    onAdd(category, name)
    setNewOptions((prev) => ({ ...prev, [category]: '' }))
  }

  return (
    <div className="space-y-4">
      {categoryOrder.map((category) => (
        <Card key={category}>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">{categoryLabels[category]}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {/* Existing options */}
            <div className="flex flex-wrap gap-2">
              {(byCategory[category] || []).map((option) => (
                <div
                  key={option.id}
                  className={`flex items-center gap-2 rounded-lg border px-3 py-1.5 ${
                    option.available ? 'bg-background' : 'bg-muted opacity-60'
                  }`}
                >
                  <Switch
                    checked={option.available}
                    onCheckedChange={(checked) => onToggle(option.id, checked)}
                    className="scale-75"
                  />
                  <span className="text-sm">{option.name}</span>
                  <button
                    onClick={() => onDelete(option.id)}
                    className="text-muted-foreground hover:text-destructive"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>

            {/* Add new */}
            <div className="flex gap-2">
              <Input
                placeholder={`Add ${categoryLabels[category].toLowerCase()}...`}
                value={newOptions[category]}
                onChange={(e) =>
                  setNewOptions((prev) => ({
                    ...prev,
                    [category]: e.target.value,
                  }))
                }
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault()
                    handleAdd(category)
                  }
                }}
                className="flex-1"
              />
              <Button
                variant="outline"
                size="icon"
                onClick={() => handleAdd(category)}
                disabled={!newOptions[category].trim()}
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
