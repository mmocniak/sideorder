import { Link, useLocation } from 'react-router-dom'
import { Coffee, History, BookOpen, Home } from 'lucide-react'
import { cn } from '@/lib/utils'

const navItems = [
  { to: '/', icon: Home, label: 'Home' },
  { to: '/history', icon: History, label: 'History' },
  { to: '/menu', icon: BookOpen, label: 'Menu' },
]

export function Header() {
  const location = useLocation()

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-cream/80 backdrop-blur-md safe-top">
      <div className="flex h-14 items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-espresso text-cream">
            <Coffee className="h-4 w-4" />
          </div>
          <span className="font-display text-lg font-semibold text-espresso">
            Side Order
          </span>
        </Link>

        <nav className="flex items-center gap-1">
          {navItems.map(({ to, icon: Icon, label }) => (
            <Link
              key={to}
              to={to}
              className={cn(
                'flex h-9 items-center gap-2 rounded-lg px-3 text-sm font-medium transition-colors',
                location.pathname === to
                  ? 'bg-espresso text-cream'
                  : 'text-roast hover:bg-oat-100'
              )}
            >
              <Icon className="h-4 w-4" />
              <span className="hidden sm:inline">{label}</span>
            </Link>
          ))}
        </nav>
      </div>
    </header>
  )
}
