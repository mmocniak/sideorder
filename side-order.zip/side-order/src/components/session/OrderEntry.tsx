import { useState } from 'react'
import { Plus, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { cn } from '@/lib/utils'
import type { MenuItem, CustomizationOption, OrderCustomizations } from '@/db/types'

interface OrderEntryProps {
  menuItems: MenuItem[]
  customizations: CustomizationOption[]
  onAddOrder: (
    item: MenuItem,
    customizations: OrderCustomizations,
    notes: string
  ) => void
}

export function OrderEntry({
  menuItems,
  customizations,
  onAddOrder,
}: OrderEntryProps) {
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null)
  const [orderCustomizations, setOrderCustomizations] =
    useState<OrderCustomizations>({})
  const [notes, setNotes] = useState('')

  const temperatures = customizations.filter((c) => c.category === 'temperature')
  const milks = customizations.filter((c) => c.category === 'milk')
  const syrups = customizations.filter((c) => c.category === 'syrup')
  const sizes = customizations.filter((c) => c.category === 'size')

  const itemsByCategory = menuItems.reduce(
    (acc, item) => {
      if (!acc[item.category]) acc[item.category] = []
      acc[item.category].push(item)
      return acc
    },
    {} as Record<string, MenuItem[]>
  )

  const handleSubmit = () => {
    if (!selectedItem) return
    onAddOrder(selectedItem, orderCustomizations, notes)
    // Reset form
    setSelectedItem(null)
    setOrderCustomizations({})
    setNotes('')
  }

  const handleClear = () => {
    setSelectedItem(null)
    setOrderCustomizations({})
    setNotes('')
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between">
          <span>New Order</span>
          {selectedItem && (
            <Button variant="ghost" size="sm" onClick={handleClear}>
              <X className="h-4 w-4 mr-1" />
              Clear
            </Button>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Item Selection */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Item</label>
          <div className="flex flex-wrap gap-2">
            {Object.entries(itemsByCategory).map(([category, items]) => (
              <div key={category} className="w-full">
                <span className="text-xs uppercase tracking-wide text-muted-foreground mb-1 block">
                  {category}
                </span>
                <div className="flex flex-wrap gap-2">
                  {items.map((item) => (
                    <Button
                      key={item.id}
                      variant={selectedItem?.id === item.id ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setSelectedItem(item)}
                      className={cn(
                        selectedItem?.id === item.id && 'ring-2 ring-terracotta'
                      )}
                    >
                      {item.name}
                    </Button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {selectedItem && (
          <>
            {/* Customizations */}
            <div className="grid grid-cols-2 gap-3">
              {sizes.length > 0 && (
                <div className="space-y-1">
                  <label className="text-sm font-medium">Size</label>
                  <Select
                    value={orderCustomizations.size || ''}
                    onValueChange={(v) =>
                      setOrderCustomizations((prev) => ({ ...prev, size: v }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select size" />
                    </SelectTrigger>
                    <SelectContent>
                      {sizes.map((s) => (
                        <SelectItem key={s.id} value={s.name}>
                          {s.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {temperatures.length > 0 && (
                <div className="space-y-1">
                  <label className="text-sm font-medium">Temp</label>
                  <Select
                    value={orderCustomizations.temperature || ''}
                    onValueChange={(v) =>
                      setOrderCustomizations((prev) => ({
                        ...prev,
                        temperature: v,
                      }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Hot/Iced" />
                    </SelectTrigger>
                    <SelectContent>
                      {temperatures.map((t) => (
                        <SelectItem key={t.id} value={t.name}>
                          {t.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {milks.length > 0 && (
                <div className="space-y-1">
                  <label className="text-sm font-medium">Milk</label>
                  <Select
                    value={orderCustomizations.milk || ''}
                    onValueChange={(v) =>
                      setOrderCustomizations((prev) => ({ ...prev, milk: v }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select milk" />
                    </SelectTrigger>
                    <SelectContent>
                      {milks.map((m) => (
                        <SelectItem key={m.id} value={m.name}>
                          {m.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {syrups.length > 0 && (
                <div className="space-y-1">
                  <label className="text-sm font-medium">Syrup</label>
                  <Select
                    value={orderCustomizations.syrup || ''}
                    onValueChange={(v) =>
                      setOrderCustomizations((prev) => ({ ...prev, syrup: v }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select syrup" />
                    </SelectTrigger>
                    <SelectContent>
                      {syrups.map((s) => (
                        <SelectItem key={s.id} value={s.name}>
                          {s.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>

            {/* Notes */}
            <div className="space-y-1">
              <label className="text-sm font-medium">Notes (optional)</label>
              <Input
                placeholder="Extra hot, light foam..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </div>

            {/* Submit */}
            <Button
              variant="accent"
              className="w-full"
              size="lg"
              onClick={handleSubmit}
            >
              <Plus className="h-5 w-5 mr-2" />
              Add Order
            </Button>
          </>
        )}
      </CardContent>
    </Card>
  )
}
