import { Link } from 'react-router-dom'
import { Clock, Users, ChevronRight, Coffee } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { formatDate, formatTime, formatDuration } from '@/lib/utils'
import type { Session } from '@/db/types'

interface SessionCardProps {
  session: Session
  orderCount?: number
}

export function SessionCard({ session, orderCount = 0 }: SessionCardProps) {
  const isActive = session.status === 'active'

  return (
    <Link to={isActive ? '/session' : `/history/${session.id}`}>
      <Card className="transition-shadow hover:shadow-warm-md">
        <CardContent className="flex items-center gap-4 p-4">
          <div
            className={`flex h-12 w-12 items-center justify-center rounded-xl ${
              isActive ? 'bg-terracotta text-white' : 'bg-oat-100 text-espresso'
            }`}
          >
            <Coffee className="h-6 w-6" />
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className="font-display font-semibold text-roast">
                {formatDate(session.startedAt)}
              </span>
              {isActive && (
                <span className="inline-flex items-center rounded-full bg-terracotta/10 px-2 py-0.5 text-xs font-medium text-terracotta">
                  Active
                </span>
              )}
            </div>

            <div className="mt-1 flex items-center gap-3 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <Clock className="h-3.5 w-3.5" />
                {formatTime(session.startedAt)}
                {session.endedAt && ` - ${formatTime(session.endedAt)}`}
              </span>
              {session.customerCount && (
                <span className="flex items-center gap-1">
                  <Users className="h-3.5 w-3.5" />
                  {session.customerCount}
                </span>
              )}
            </div>

            <div className="mt-1 text-sm text-muted-foreground">
              {orderCount} order{orderCount !== 1 ? 's' : ''}
              {session.endedAt && (
                <span className="ml-2">
                  · {formatDuration(session.startedAt, session.endedAt)}
                </span>
              )}
            </div>
          </div>

          <ChevronRight className="h-5 w-5 text-oat-400" />
        </CardContent>
      </Card>
    </Link>
  )
}
