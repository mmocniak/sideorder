import { Clock, Coffee, Users } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { formatDuration } from '@/lib/utils'
import type { Session } from '@/db/types'

interface SessionStatsProps {
  session: Session
  orderCount: number
}

export function SessionStats({ session, orderCount }: SessionStatsProps) {
  const isActive = session.status === 'active'

  return (
    <div className="grid grid-cols-3 gap-3">
      <Card>
        <CardContent className="flex flex-col items-center p-4">
          <Coffee className="h-5 w-5 text-terracotta mb-1" />
          <span className="text-2xl font-display font-bold text-roast">
            {orderCount}
          </span>
          <span className="text-xs text-muted-foreground">Orders</span>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="flex flex-col items-center p-4">
          <Clock className="h-5 w-5 text-terracotta mb-1" />
          <span className="text-2xl font-display font-bold text-roast">
            {formatDuration(session.startedAt, session.endedAt)}
          </span>
          <span className="text-xs text-muted-foreground">
            {isActive ? 'Elapsed' : 'Duration'}
          </span>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="flex flex-col items-center p-4">
          <Users className="h-5 w-5 text-terracotta mb-1" />
          <span className="text-2xl font-display font-bold text-roast">
            {session.customerCount ?? '—'}
          </span>
          <span className="text-xs text-muted-foreground">Customers</span>
        </CardContent>
      </Card>
    </div>
  )
}
