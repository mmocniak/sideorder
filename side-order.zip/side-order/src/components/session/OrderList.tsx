import { Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { formatTime } from '@/lib/utils'
import type { Order } from '@/db/types'

interface OrderListProps {
  orders: Order[]
  onDeleteOrder?: (id: string) => void
  showDelete?: boolean
}

export function OrderList({
  orders,
  onDeleteOrder,
  showDelete = false,
}: OrderListProps) {
  if (orders.length === 0) {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          No orders yet — they'll appear here as you add them.
        </CardContent>
      </Card>
    )
  }

  // Show most recent first
  const sortedOrders = [...orders].sort((a, b) => b.timestamp - a.timestamp)

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">
          Orders ({orders.length})
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-0 px-0">
        {sortedOrders.map((order, index) => {
          const customizationParts = [
            order.customizations.size,
            order.customizations.temperature,
            order.customizations.milk,
            order.customizations.syrup,
          ].filter(Boolean)

          return (
            <div key={order.id}>
              {index > 0 && <Separator />}
              <div className="flex items-start justify-between px-5 py-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-roast">
                      {order.itemName}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {formatTime(order.timestamp)}
                    </span>
                  </div>
                  {customizationParts.length > 0 && (
                    <p className="text-sm text-muted-foreground mt-0.5">
                      {customizationParts.join(' · ')}
                    </p>
                  )}
                  {order.notes && (
                    <p className="text-sm text-muted-foreground mt-0.5 italic">
                      "{order.notes}"
                    </p>
                  )}
                </div>
                {showDelete && onDeleteOrder && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-muted-foreground hover:text-destructive"
                    onClick={() => onDeleteOrder(order.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          )
        })}
      </CardContent>
    </Card>
  )
}
