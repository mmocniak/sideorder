# Side Order

Session-based order tracking for Side Hustle Coffee.

## Features

- **Session Management**: Start, run, and close daily sessions
- **Order Logging**: Quick-entry during service with timestamps
- **Menu Management**: Maintain drinks and customization options
- **Session History**: Review past sessions with order summaries
- **Menu Snapshots**: Each session preserves the menu as it was

## Getting Started

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start the development server:**
   ```bash
   npm run dev
   ```

3. **Open in your browser:**
   Navigate to `http://localhost:5173`

## Install as PWA

On iOS:
1. Open the app in Safari
2. Tap the Share button
3. Tap "Add to Home Screen"

On Android:
1. Open the app in Chrome
2. Tap the menu (⋮)
3. Tap "Add to Home screen"

## Tech Stack

- **React** + **TypeScript**
- **Vite** (build tool)
- **Tailwind CSS** + **ShadCN/UI** (styling)
- **Zustand** (state management)
- **Dexie.js** (IndexedDB for local storage)
- **PWA** (installable, offline-capable)

## Project Structure

```
src/
├── components/
│   ├── ui/          # ShadCN primitives
│   ├── layout/      # App shell, header
│   ├── session/     # Session and order components
│   └── menu/        # Menu management components
├── pages/           # Route pages
├── stores/          # Zustand stores
├── db/              # Dexie database setup
└── lib/             # Utilities
```

## Color Palette (Warm Counter)

| Role       | Color     | Hex       |
|------------|-----------|-----------|
| Background | Cream     | `#FAF7F2` |
| Surface    | White     | `#FFFFFF` |
| Primary    | Espresso  | `#5C4033` |
| Accent     | Terracotta| `#C67D4D` |
| Muted      | Oat       | `#D4C9BE` |
| Text       | Dark Roast| `#2C2420` |
