import type { Config } from 'tailwindcss'

export default {
  darkMode: ["class"],
  content: [
    './index.html',
    './src/**/*.{ts,tsx}',
  ],
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        // Warm Counter palette
        cream: {
          DEFAULT: "#FAF7F2",
          50: "#FDFCFA",
          100: "#FAF7F2",
          200: "#F0E9DD",
        },
        espresso: {
          DEFAULT: "#5C4033",
          50: "#F5F0EC",
          100: "#E6DDD5",
          200: "#C9B8A6",
          300: "#A68E76",
          400: "#7A5F48",
          500: "#5C4033",
          600: "#4A3329",
          700: "#38271F",
          800: "#261A15",
          900: "#140E0B",
        },
        terracotta: {
          DEFAULT: "#C67D4D",
          50: "#FCF5F0",
          100: "#F7E8DD",
          200: "#EDD0BA",
          300: "#DFB191",
          400: "#D29468",
          500: "#C67D4D",
          600: "#A86239",
          700: "#7E4A2B",
          800: "#54311D",
          900: "#2A190E",
        },
        oat: {
          DEFAULT: "#D4C9BE",
          50: "#FAF9F7",
          100: "#F0EDE8",
          200: "#E2DCD3",
          300: "#D4C9BE",
          400: "#BFB0A0",
          500: "#A99782",
          600: "#8A7862",
          700: "#675A4A",
          800: "#453C31",
          900: "#221E19",
        },
        roast: {
          DEFAULT: "#2C2420",
          50: "#F7F6F5",
          100: "#E8E5E3",
          200: "#CCC6C1",
          300: "#A99F98",
          400: "#7A6F66",
          500: "#544943",
          600: "#3E3632",
          700: "#2C2420",
          800: "#1D1816",
          900: "#0E0C0B",
        },
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['DM Sans', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        'warm-sm': '0 1px 2px 0 rgba(92, 64, 51, 0.05)',
        'warm': '0 1px 3px 0 rgba(92, 64, 51, 0.1), 0 1px 2px -1px rgba(92, 64, 51, 0.1)',
        'warm-md': '0 4px 6px -1px rgba(92, 64, 51, 0.1), 0 2px 4px -2px rgba(92, 64, 51, 0.1)',
        'warm-lg': '0 10px 15px -3px rgba(92, 64, 51, 0.1), 0 4px 6px -4px rgba(92, 64, 51, 0.1)',
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
} satisfies Config
